export enum UserRole {
  OWNER = 'OWNER',
  EMPLOYEE = 'EMPLOYEE',
  GOVT = 'GOVT'
}

export enum MedicineType {
  TABLET = 'Tablet',
  CAPSULE = 'Capsule',
  SYRUP = 'Syrup',
  INJECTION = 'Injection',
  CREAM = 'Cream',
  OTHER = 'Other'
}

export interface Medicine {
  id: string;
  name: string;
  saltComposition: string;
  batchNumber: string;
  stockCount: number;
  expiryDate: string; // ISO Date string
  manufacturingDate: string;
  type: MedicineType;
  company: string;
  barcode: string;
  gstCode: string;
  addedBy: string;
  lastUpdated: string;
  minStockThreshold: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  pharmacyName?: string;
}

export interface ComplianceReport {
  id: string;
  generatedDate: string;
  score: number;
  issues: string[];
  status: 'Pass' | 'Fail' | 'Warning';
}

export type ViewState = 
  | 'LOGIN' 
  | 'DASHBOARD' 
  | 'INVENTORY' 
  | 'SCANNER' 
  | 'GOVT_PORTAL' 
  | 'SETTINGS';