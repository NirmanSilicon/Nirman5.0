import React, { useState, useEffect, useMemo } from 'react';
import { 
  UserRole, 
  ViewState, 
  User, 
  Medicine, 
  MedicineType,
  ComplianceReport 
} from './types';
import { INITIAL_MEDICINES, MOCK_USERS } from './services/mockService';
import { Icons } from './components/Icons';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';

// --- Sub-Components ---

// 1. Sidebar
const Sidebar = ({ 
  role, 
  currentView, 
  onChangeView, 
  onLogout,
  isOpen,
  toggleSidebar
}: { 
  role: UserRole, 
  currentView: ViewState, 
  onChangeView: (v: ViewState) => void, 
  onLogout: () => void,
  isOpen: boolean,
  toggleSidebar: () => void
}) => {
  const menuItems = [
    { id: 'DASHBOARD', label: 'Dashboard', icon: Icons.Home, roles: [UserRole.OWNER, UserRole.EMPLOYEE, UserRole.GOVT] },
    { id: 'INVENTORY', label: 'Inventory', icon: Icons.Package, roles: [UserRole.OWNER, UserRole.EMPLOYEE] },
    { id: 'SCANNER', label: 'Scanner', icon: Icons.Barcode, roles: [UserRole.OWNER, UserRole.EMPLOYEE] },
    { id: 'GOVT_PORTAL', label: 'Compliance', icon: Icons.ShieldCheck, roles: [UserRole.OWNER, UserRole.GOVT] },
    { id: 'SETTINGS', label: 'Settings', icon: Icons.Settings, roles: [UserRole.OWNER, UserRole.EMPLOYEE, UserRole.GOVT] },
  ];

  const filteredItems = menuItems.filter(item => item.roles.includes(role));

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden"
          onClick={toggleSidebar}
        />
      )}
      
      <aside className={`
        fixed inset-y-0 left-0 z-30 w-64 bg-white dark:bg-gray-800 shadow-xl transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        md:relative md:translate-x-0
      `}>
        <div className="h-full flex flex-col">
          <div className="p-6 flex items-center justify-between border-b dark:border-gray-700">
            <div className="flex items-center space-x-2 text-med-blue font-bold text-xl">
              <Icons.Activity className="w-8 h-8" />
              <span>MedInvento</span>
            </div>
            <button onClick={toggleSidebar} className="md:hidden text-gray-500">
              <Icons.X />
            </button>
          </div>

          <nav className="flex-1 px-4 py-6 space-y-2">
            {filteredItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onChangeView(item.id as ViewState);
                    if (window.innerWidth < 768) toggleSidebar();
                  }}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors duration-200 ${
                    isActive 
                      ? 'bg-med-blue text-white shadow-md' 
                      : 'text-gray-600 dark:text-gray-300 hover:bg-med-sky hover:text-med-blue dark:hover:bg-gray-700'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </button>
              );
            })}
          </nav>

          <div className="p-4 border-t dark:border-gray-700">
            <button
              onClick={onLogout}
              className="w-full flex items-center space-x-3 px-4 py-3 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
            >
              <Icons.LogOut className="w-5 h-5" />
              <span className="font-medium">Logout</span>
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};

// 2. Dashboard Components
const StatCard = ({ title, value, subtext, icon: Icon, colorClass, textColor }: any) => (
  <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-100 dark:border-gray-700 flex items-start justify-between">
    <div>
      <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</p>
      <h3 className={`text-2xl font-bold mt-1 ${textColor || 'text-gray-900 dark:text-white'}`}>{value}</h3>
      {subtext && <p className="text-xs text-gray-400 mt-1">{subtext}</p>}
    </div>
    <div className={`p-3 rounded-lg ${colorClass}`}>
      <Icon className="w-6 h-6 text-white" />
    </div>
  </div>
);

// 3. Inventory Screen
const InventoryView = ({ 
  medicines, 
  onAddMedicine, 
  onDeleteMedicine,
  currentUser 
}: {
  medicines: Medicine[],
  onAddMedicine: (m: Medicine) => void,
  onDeleteMedicine: (id: string) => void,
  currentUser: User
}) => {
  const [search, setSearch] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newMed, setNewMed] = useState<Partial<Medicine>>({
    type: MedicineType.TABLET,
    stockCount: 0,
    minStockThreshold: 50
  });

  const filtered = useMemo(() => {
    return medicines.filter(m => 
      m.name.toLowerCase().includes(search.toLowerCase()) || 
      m.batchNumber.toLowerCase().includes(search.toLowerCase())
    );
  }, [medicines, search]);

  const getExpiryColor = (dateStr: string) => {
    const days = (new Date(dateStr).getTime() - new Date().getTime()) / (1000 * 3600 * 24);
    if (days < 30) return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300';
    if (days < 90) return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300';
    return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300';
  };

  const handleAdd = () => {
    if (!newMed.name || !newMed.batchNumber) return;
    const med: Medicine = {
      id: Math.random().toString(36).substr(2, 9),
      name: newMed.name,
      saltComposition: newMed.saltComposition || '',
      batchNumber: newMed.batchNumber,
      stockCount: Number(newMed.stockCount),
      expiryDate: newMed.expiryDate || new Date().toISOString(),
      manufacturingDate: newMed.manufacturingDate || new Date().toISOString(),
      type: newMed.type as MedicineType,
      company: newMed.company || '',
      barcode: Math.floor(Math.random() * 1000000000000).toString(),
      gstCode: '3004',
      addedBy: currentUser.name,
      lastUpdated: new Date().toISOString(),
      minStockThreshold: Number(newMed.minStockThreshold)
    };
    onAddMedicine(med);
    setShowAddModal(false);
    setNewMed({ type: MedicineType.TABLET, stockCount: 0, minStockThreshold: 50 });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Inventory Management</h2>
          <p className="text-gray-500 dark:text-gray-400">Manage stock, batches, and prices</p>
        </div>
        <div className="flex gap-3 w-full sm:w-auto">
          <div className="relative flex-1 sm:flex-initial">
            <Icons.Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input 
              type="text" 
              placeholder="Search medicine..." 
              className="pl-9 pr-4 py-2 w-full border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-med-blue focus:outline-none"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <button 
            onClick={() => setShowAddModal(true)}
            className="flex items-center space-x-2 bg-med-blue hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
          >
            <Icons.Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Add Medicine</span>
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50 dark:bg-gray-700/50 text-gray-500 dark:text-gray-400 font-medium text-xs uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4">Medicine Name</th>
                <th className="px-6 py-4">Batch No.</th>
                <th className="px-6 py-4">Stock</th>
                <th className="px-6 py-4">Expiry</th>
                <th className="px-6 py-4">Type</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
              {filtered.map((med) => (
                <tr key={med.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                  <td className="px-6 py-4">
                    <div className="font-medium text-gray-900 dark:text-white">{med.name}</div>
                    <div className="text-xs text-gray-400">{med.saltComposition}</div>
                  </td>
                  <td className="px-6 py-4 text-gray-600 dark:text-gray-300 font-mono text-sm">{med.batchNumber}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-2">
                      <span className={`font-semibold ${med.stockCount < med.minStockThreshold ? 'text-red-600' : 'text-gray-700 dark:text-gray-200'}`}>
                        {med.stockCount}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getExpiryColor(med.expiryDate)}`}>
                      {new Date(med.expiryDate).toLocaleDateString()}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-xs text-gray-500 border border-gray-200 dark:border-gray-600 rounded px-2 py-1">
                      {med.type}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => onDeleteMedicine(med.id)}
                      className="text-gray-400 hover:text-red-500 transition-colors"
                    >
                      <Icons.Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl w-full max-w-lg p-6 shadow-2xl overflow-y-auto max-h-[90vh]">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Add New Medicine</h3>
              <button onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-gray-600"><Icons.X /></button>
            </div>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <input placeholder="Name" className="p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white" value={newMed.name || ''} onChange={e => setNewMed({...newMed, name: e.target.value})} />
                <input placeholder="Batch No" className="p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white" value={newMed.batchNumber || ''} onChange={e => setNewMed({...newMed, batchNumber: e.target.value})} />
              </div>
              <input placeholder="Salt Composition" className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white" value={newMed.saltComposition || ''} onChange={e => setNewMed({...newMed, saltComposition: e.target.value})} />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Stock Count</label>
                  <input type="number" className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white" value={newMed.stockCount} onChange={e => setNewMed({...newMed, stockCount: parseInt(e.target.value)})} />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Type</label>
                  <select className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white" value={newMed.type} onChange={e => setNewMed({...newMed, type: e.target.value as MedicineType})}>
                    {Object.values(MedicineType).map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Expiry Date</label>
                  <input type="date" className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white" onChange={e => setNewMed({...newMed, expiryDate: e.target.value})} />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Mfg Date</label>
                  <input type="date" className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white" onChange={e => setNewMed({...newMed, manufacturingDate: e.target.value})} />
                </div>
              </div>
              <button onClick={handleAdd} className="w-full bg-med-blue hover:bg-blue-700 text-white font-bold py-3 rounded-xl shadow-md transition-all">Save Medicine</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// 4. Scanner View
const ScannerView = ({ onScan }: { onScan: (code: string) => void }) => {
  const [scanning, setScanning] = useState(false);
  const [scannedCode, setScannedCode] = useState<string | null>(null);

  const simulateScan = () => {
    setScanning(true);
    setTimeout(() => {
      const randomCode = Math.floor(Math.random() * 1000000000000).toString();
      setScannedCode(randomCode);
      setScanning(false);
      onScan(randomCode);
    }, 2000);
  };

  return (
    <div className="flex flex-col items-center justify-center h-[60vh] space-y-8 text-center">
      <div className="relative">
        <div className={`w-64 h-64 border-4 rounded-3xl flex items-center justify-center bg-gray-100 dark:bg-gray-800 transition-colors ${scanning ? 'border-med-green animate-pulse' : 'border-gray-300 dark:border-gray-600'}`}>
          {scanning ? (
            <Icons.Barcode className="w-32 h-32 text-med-green animate-bounce" />
          ) : (
            <Icons.Maximize className="w-20 h-20 text-gray-400" />
          )}
        </div>
        {scanning && (
          <div className="absolute top-0 left-0 w-full h-1 bg-red-500 animate-[scan_2s_ease-in-out_infinite]" />
        )}
      </div>

      <div className="space-y-4">
        <h2 className="text-2xl font-bold dark:text-white">
          {scanning ? 'Scanning...' : 'Place Barcode in Frame'}
        </h2>
        <p className="text-gray-500 max-w-xs mx-auto">
          Scan GS1 codes to verify batch validity, expiry, and manufacturer details automatically.
        </p>
        
        {scannedCode && (
          <div className="bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300 px-4 py-2 rounded-lg font-mono">
            Scanned: {scannedCode}
          </div>
        )}

        <button 
          onClick={simulateScan}
          disabled={scanning}
          className="bg-med-blue hover:bg-blue-700 text-white px-8 py-3 rounded-full font-semibold shadow-lg transition-transform transform active:scale-95 disabled:opacity-50"
        >
          {scanning ? 'Processing...' : 'Start Scan'}
        </button>
      </div>
    </div>
  );
};

// 5. Government Portal
const GovtPortalView = ({ medicines }: { medicines: Medicine[] }) => {
  const [syncing, setSyncing] = useState(false);
  const [lastSync, setLastSync] = useState('Never');

  const complianceScore = useMemo(() => {
    let score = 100;
    const expired = medicines.filter(m => new Date(m.expiryDate) < new Date()).length;
    const lowStock = medicines.filter(m => m.stockCount < m.minStockThreshold).length;
    score -= (expired * 5); // Heavy penalty for expired
    score -= (lowStock * 1); // Minor penalty for low stock
    return Math.max(0, Math.min(100, score));
  }, [medicines]);

  const handleSync = () => {
    setSyncing(true);
    setTimeout(() => {
      setSyncing(false);
      setLastSync(new Date().toLocaleTimeString());
    }, 2000);
  };

  const COLORS = ['#43A047', '#FFBB28', '#FF8042', '#EF5350'];
  const chartData = [
    { name: 'Safe', value: medicines.filter(m => new Date(m.expiryDate) > new Date(Date.now() + 86400000 * 90)).length },
    { name: 'Warning', value: medicines.filter(m => {
        const d = new Date(m.expiryDate);
        const now = new Date();
        return d > now && d < new Date(now.getTime() + 86400000 * 90);
    }).length },
    { name: 'Expired', value: medicines.filter(m => new Date(m.expiryDate) < new Date()).length }
  ];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Government Compliance Portal</h2>
          <p className="text-gray-500">Official reporting and data synchronization gateway.</p>
        </div>
        <button 
          onClick={handleSync}
          disabled={syncing}
          className="flex items-center space-x-2 bg-gray-900 dark:bg-white dark:text-gray-900 text-white px-6 py-3 rounded-lg hover:shadow-lg transition-all disabled:opacity-50"
        >
          {syncing ? <Icons.Activity className="animate-spin w-5 h-5" /> : <Icons.ShieldCheck className="w-5 h-5" />}
          <span>{syncing ? 'Syncing...' : 'Sync Data'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col items-center text-center">
          <div className="relative w-32 h-32 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="64" cy="64" r="56" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-gray-200 dark:text-gray-700" />
              <circle cx="64" cy="64" r="56" stroke="currentColor" strokeWidth="8" fill="transparent" strokeDasharray={351.86} strokeDashoffset={351.86 - (351.86 * complianceScore) / 100} className={`${complianceScore > 80 ? 'text-green-500' : complianceScore > 50 ? 'text-yellow-500' : 'text-red-500'} transition-all duration-1000`} />
            </svg>
            <span className="absolute text-2xl font-bold dark:text-white">{complianceScore}%</span>
          </div>
          <h3 className="mt-4 font-semibold text-gray-900 dark:text-white">Compliance Score</h3>
          <p className="text-sm text-gray-500">Based on expiry & stock protocols</p>
        </div>

        <div className="md:col-span-2 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
          <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Stock Health Distribution</h3>
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend verticalAlign="middle" align="right" />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-6">
        <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Compliance Logs</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
            <div className="flex items-center space-x-3">
              <Icons.CheckCircle className="w-5 h-5 text-green-500" />
              <div>
                <p className="font-medium text-gray-900 dark:text-white">Daily Data Sync</p>
                <p className="text-xs text-gray-500">Last successful sync: {lastSync}</p>
              </div>
            </div>
            <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Verified</span>
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
            <div className="flex items-center space-x-3">
              <Icons.AlertTriangle className="w-5 h-5 text-yellow-500" />
              <div>
                <p className="font-medium text-gray-900 dark:text-white">Expiry Warning Check</p>
                <p className="text-xs text-gray-500">{medicines.filter(m => new Date(m.expiryDate) < new Date(Date.now() + 86400000 * 30)).length} batches expiring soon</p>
              </div>
            </div>
            <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">Action Needed</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// 6. Login View
const LoginView = ({ onLogin }: { onLogin: (u: User) => void }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole>(UserRole.OWNER);
  const [govtCode, setGovtCode] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (selectedRole === UserRole.GOVT && govtCode !== 'GOVT2024') {
      setError('Invalid Government Verification Code');
      return;
    }

    // Mock Login
    const user = MOCK_USERS.find(u => u.email === email && u.role === selectedRole);
    if (user) {
      onLogin(user);
    } else {
      // Create a dummy user for demo if not in mock
      onLogin({
        id: 'new',
        name: email.split('@')[0],
        email,
        role: selectedRole,
        pharmacyName: 'Demo Pharmacy'
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 p-4">
      <div className="w-full max-w-md bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden">
        <div className="bg-med-blue p-8 text-center">
          <Icons.Activity className="w-16 h-16 text-white mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-white">MedInvento</h1>
          <p className="text-blue-100 mt-2">Pharmacy Compliance & Inventory</p>
        </div>
        
        <form onSubmit={handleLogin} className="p-8 space-y-6">
          <div className="flex bg-gray-100 dark:bg-gray-700 p-1 rounded-lg">
            {Object.values(UserRole).map(role => (
              <button
                key={role}
                type="button"
                onClick={() => setSelectedRole(role)}
                className={`flex-1 py-2 text-xs font-bold rounded-md transition-all ${
                  selectedRole === role 
                    ? 'bg-white dark:bg-gray-600 text-med-blue shadow-sm' 
                    : 'text-gray-500 dark:text-gray-400'
                }`}
              >
                {role}
              </button>
            ))}
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Email Address</label>
              <input 
                type="email" 
                required
                className="w-full mt-1 p-3 border rounded-lg focus:ring-2 focus:ring-med-blue focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Password</label>
              <input 
                type="password" 
                required
                className="w-full mt-1 p-3 border rounded-lg focus:ring-2 focus:ring-med-blue focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            
            {selectedRole === UserRole.GOVT && (
              <div className="animate-fade-in">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Govt. Verification Code</label>
                <input 
                  type="text" 
                  placeholder="Enter 'GOVT2024'"
                  className="w-full mt-1 p-3 border border-med-green rounded-lg focus:ring-2 focus:ring-med-green focus:outline-none dark:bg-gray-700 dark:text-white"
                  value={govtCode}
                  onChange={(e) => setGovtCode(e.target.value)}
                />
              </div>
            )}
          </div>

          {error && <p className="text-red-500 text-sm text-center">{error}</p>}

          <button type="submit" className="w-full bg-med-blue hover:bg-blue-700 text-white font-bold py-3 rounded-xl shadow-lg transition-transform transform active:scale-95">
            Access Dashboard
          </button>

          <div className="text-center text-xs text-gray-400 mt-4">
            By logging in, you agree to MedInvento Compliance Terms.
          </div>
        </form>
      </div>
    </div>
  );
};

// --- Main App Component ---

const App = () => {
  const [user, setUser] = useState<User | null>(null);
  const [view, setView] = useState<ViewState>('LOGIN');
  const [medicines, setMedicines] = useState<Medicine[]>(INITIAL_MEDICINES);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  // Toggle Dark Mode
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const handleLogin = (u: User) => {
    setUser(u);
    setView(u.role === UserRole.GOVT ? 'GOVT_PORTAL' : 'DASHBOARD');
  };

  const handleLogout = () => {
    setUser(null);
    setView('LOGIN');
  };

  const handleDeleteMed = (id: string) => {
    setMedicines(prev => prev.filter(m => m.id !== id));
  };

  const handleAddMed = (med: Medicine) => {
    setMedicines(prev => [med, ...prev]);
  };

  const handleScan = (code: string) => {
    alert(`Scanned Barcode: ${code}. In a real app, this would fetch details from ML Kit.`);
  };

  // Dashboard calculations
  const totalStock = medicines.reduce((acc, m) => acc + m.stockCount, 0);
  const lowStock = medicines.filter(m => m.stockCount < m.minStockThreshold).length;
  const expired = medicines.filter(m => new Date(m.expiryDate) < new Date()).length;
  
  if (!user) {
    return <LoginView onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex">
      <Sidebar 
        role={user.role} 
        currentView={view} 
        onChangeView={setView} 
        onLogout={handleLogout}
        isOpen={sidebarOpen}
        toggleSidebar={() => setSidebarOpen(!sidebarOpen)}
      />

      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Header */}
        <header className="bg-white dark:bg-gray-800 shadow-sm border-b dark:border-gray-700 px-6 py-4 flex items-center justify-between z-10">
          <div className="flex items-center gap-4">
            <button onClick={() => setSidebarOpen(true)} className="md:hidden text-gray-600 dark:text-white">
              <Icons.Menu />
            </button>
            <h1 className="text-xl font-bold text-gray-800 dark:text-white hidden sm:block">
              {view === 'DASHBOARD' ? `Welcome, ${user.name}` : 
               view === 'GOVT_PORTAL' ? 'Government Inspection' : 
               view.charAt(0) + view.slice(1).toLowerCase()}
            </h1>
          </div>
          <div className="flex items-center space-x-4">
            <button onClick={() => setDarkMode(!darkMode)} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300">
              {darkMode ? <Icons.Sun className="w-5 h-5" /> : <Icons.Moon className="w-5 h-5" />}
            </button>
            <div className="w-8 h-8 rounded-full bg-med-blue flex items-center justify-center text-white font-bold">
              {user.name.charAt(0)}
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-auto p-6 scroll-smooth">
          {view === 'DASHBOARD' && (
            <div className="space-y-6 animate-fade-in">
              {/* Quick Stats */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard 
                  title="Total Stock" 
                  value={totalStock.toLocaleString()} 
                  icon={Icons.Box} 
                  colorClass="bg-blue-500" 
                />
                <StatCard 
                  title="Low Stock" 
                  value={lowStock} 
                  subtext="Items below threshold"
                  icon={Icons.AlertTriangle} 
                  colorClass="bg-yellow-500" 
                  textColor="text-yellow-600 dark:text-yellow-400"
                />
                <StatCard 
                  title="Expired" 
                  value={expired} 
                  subtext="Remove immediately"
                  icon={Icons.Trash2} 
                  colorClass="bg-red-500" 
                  textColor="text-red-600 dark:text-red-400"
                />
                 <StatCard 
                  title="Monthly Sales" 
                  value="$12,450" 
                  icon={Icons.BarChart2} 
                  colorClass="bg-green-500" 
                  textColor="text-green-600 dark:text-green-400"
                />
              </div>

              {/* Chart */}
              <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
                <h3 className="font-bold text-gray-900 dark:text-white mb-4">Stock Composition</h3>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={[
                      {name: 'Tablets', count: medicines.filter(m => m.type === MedicineType.TABLET).length},
                      {name: 'Syrups', count: medicines.filter(m => m.type === MedicineType.SYRUP).length},
                      {name: 'Capsules', count: medicines.filter(m => m.type === MedicineType.CAPSULE).length},
                      {name: 'Injections', count: medicines.filter(m => m.type === MedicineType.INJECTION).length},
                    ]}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={darkMode ? '#374151' : '#E5E7EB'} />
                      <XAxis dataKey="name" tick={{fill: darkMode ? '#9CA3AF' : '#4B5563'}} />
                      <YAxis tick={{fill: darkMode ? '#9CA3AF' : '#4B5563'}} />
                      <Tooltip 
                        contentStyle={{
                          backgroundColor: darkMode ? '#1F2937' : '#FFFFFF', 
                          borderColor: darkMode ? '#374151' : '#E5E7EB',
                          color: darkMode ? '#F3F4F6' : '#111827'
                        }} 
                      />
                      <Bar dataKey="count" fill="#1E88E5" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Quick Actions */}
              {user.role === UserRole.OWNER && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <button onClick={() => setView('INVENTORY')} className="p-4 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-md transition-shadow flex flex-col items-center justify-center space-y-2 text-med-blue">
                    <Icons.Plus className="w-6 h-6" />
                    <span className="font-medium">Add Medicine</span>
                  </button>
                  <button onClick={() => setView('SCANNER')} className="p-4 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-md transition-shadow flex flex-col items-center justify-center space-y-2 text-med-green">
                    <Icons.Barcode className="w-6 h-6" />
                    <span className="font-medium">Scan Stock</span>
                  </button>
                  <button onClick={() => setView('GOVT_PORTAL')} className="p-4 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-md transition-shadow flex flex-col items-center justify-center space-y-2 text-purple-500">
                    <Icons.FileText className="w-6 h-6" />
                    <span className="font-medium">Reports</span>
                  </button>
                  <button className="p-4 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-md transition-shadow flex flex-col items-center justify-center space-y-2 text-orange-500">
                    <Icons.Users className="w-6 h-6" />
                    <span className="font-medium">Staff</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {view === 'INVENTORY' && (
            <InventoryView 
              medicines={medicines} 
              onAddMedicine={handleAddMed}
              onDeleteMedicine={handleDeleteMed}
              currentUser={user}
            />
          )}

          {view === 'SCANNER' && (
            <ScannerView onScan={handleScan} />
          )}

          {view === 'GOVT_PORTAL' && (
            <GovtPortalView medicines={medicines} />
          )}

          {view === 'SETTINGS' && (
            <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
              <h2 className="text-2xl font-bold mb-6 dark:text-white">Settings</h2>
              <div className="space-y-6">
                <div className="flex items-center justify-between py-4 border-b dark:border-gray-700">
                  <div>
                    <h3 className="font-medium dark:text-white">Pharmacy Profile</h3>
                    <p className="text-sm text-gray-500">Edit pharmacy name and license details</p>
                  </div>
                  <Icons.ChevronRight className="text-gray-400" />
                </div>
                <div className="flex items-center justify-between py-4 border-b dark:border-gray-700">
                  <div>
                    <h3 className="font-medium dark:text-white">Notifications</h3>
                    <p className="text-sm text-gray-500">Manage expiry alerts and stock warnings</p>
                  </div>
                  <div className="w-10 h-6 bg-med-blue rounded-full relative cursor-pointer">
                    <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full"></div>
                  </div>
                </div>
                <div className="flex items-center justify-between py-4 border-b dark:border-gray-700">
                  <div>
                    <h3 className="font-medium dark:text-white">Data Export</h3>
                    <p className="text-sm text-gray-500">Download inventory as CSV/PDF</p>
                  </div>
                  <button className="text-med-blue text-sm font-bold">Export</button>
                </div>
                <div className="pt-4">
                  <button onClick={handleLogout} className="w-full py-3 text-red-500 border border-red-200 dark:border-red-900 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 font-medium">
                    Log Out
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Global Helper to handle icon maximizing if scanner needs it */}
      <Icons.Maximize className="hidden" /> 
    </div>
  );
};

export default App;