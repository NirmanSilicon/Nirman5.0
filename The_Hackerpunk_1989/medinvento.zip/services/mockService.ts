import { Medicine, MedicineType, UserRole, User } from '../types';

export const INITIAL_MEDICINES: Medicine[] = [
  {
    id: '1',
    name: 'Paracetamol 500mg',
    saltComposition: 'Paracetamol',
    batchNumber: 'B1209X',
    stockCount: 1500,
    expiryDate: new Date(Date.now() + 86400000 * 365).toISOString(), // 1 year from now
    manufacturingDate: '2023-01-15',
    type: MedicineType.TABLET,
    company: 'MediCare Pharma',
    barcode: '8901234567890',
    gstCode: '3004',
    addedBy: 'Owner',
    lastUpdated: new Date().toISOString(),
    minStockThreshold: 200,
  },
  {
    id: '2',
    name: 'Amoxycillin 250mg',
    saltComposition: 'Amoxycillin',
    batchNumber: 'AMX-99',
    stockCount: 45,
    expiryDate: new Date(Date.now() + 86400000 * 20).toISOString(), // 20 days (Critical Red)
    manufacturingDate: '2022-05-10',
    type: MedicineType.CAPSULE,
    company: 'SunLife Labs',
    barcode: '8909876543210',
    gstCode: '3004',
    addedBy: 'Emp01',
    lastUpdated: new Date().toISOString(),
    minStockThreshold: 50,
  },
  {
    id: '3',
    name: 'Cough Syrup Alpha',
    saltComposition: 'Dextromethorphan',
    batchNumber: 'CS-202',
    stockCount: 80,
    expiryDate: new Date(Date.now() + 86400000 * 75).toISOString(), // 75 days (Warning Yellow)
    manufacturingDate: '2023-08-01',
    type: MedicineType.SYRUP,
    company: 'HealthWell',
    barcode: '1122334455667',
    gstCode: '3004',
    addedBy: 'Owner',
    lastUpdated: new Date().toISOString(),
    minStockThreshold: 100,
  },
  {
    id: '4',
    name: 'Insulin Rapid',
    saltComposition: 'Insulin Human',
    batchNumber: 'INS-01',
    stockCount: 12,
    expiryDate: new Date(Date.now() + 86400000 * 180).toISOString(),
    manufacturingDate: '2023-11-20',
    type: MedicineType.INJECTION,
    company: 'DiabetCare',
    barcode: '5566778899001',
    gstCode: '3004',
    addedBy: 'Owner',
    lastUpdated: new Date().toISOString(),
    minStockThreshold: 20,
  }
];

export const MOCK_USERS: User[] = [
  { id: 'u1', name: 'Dr. John Doe', email: 'owner@med.com', role: UserRole.OWNER, pharmacyName: 'City Central Pharmacy' },
  { id: 'u2', name: 'Jane Smith', email: 'emp@med.com', role: UserRole.EMPLOYEE, pharmacyName: 'City Central Pharmacy' },
  { id: 'u3', name: 'Officer Brown', email: 'govt@med.com', role: UserRole.GOVT }
];